<?php
	session_start();
	mysqli_report(MYSQLI_REPORT_STRICT);	
	$con= mysqli_connect('localhost','root','');
	if(!$con)
	{
		echo 'Not Connected to server';
	}
	if(!mysqli_select_db($con,'job_portal'))
	{
		echo 'db not selected';
	}
	$log_username=$_POST['Email'];
	$log_password=$_POST['Password'];
	$type=0;
	$query = mysqli_query($con, "SELECT email,password,type_id FROM user_account WHERE email='$log_username' AND password='$log_password'");
	// Exception Handling //
	if (mysqli_num_rows($query) > 0) {
		while($row = mysqli_fetch_array($query)){	
			$type=$row['type_id'];
			$_SESSION["email"] = $log_username;
			$_SESSION["password"]= $log_password;
		}
		if($type == 0){
			echo "<script type='text/javascript'>alert('Login Successful !!'); window.location.href='HRsignup.html';</script>";
		}
		else if($type == 1)
			echo "<script type='text/javascript'>alert('Login Successful !!'); window.location.href='Jobseekersignup.html';</script>";
	}
	else {
			echo "Invalid Password Try Again :(";
			header("Refresh:1 ; url=Login.html");

	}
		
?>
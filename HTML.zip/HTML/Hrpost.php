<?php

	session_start();
	mysqli_report(MYSQLI_REPORT_STRICT);	
	$con= mysqli_connect('localhost','root','');
	if(!$con)
	{
		echo 'Not Connected to server';
	}
	if(!mysqli_select_db($con,'job_portal'))
	{
		echo 'db not selected';
	}
	$jobRole=$_POST['Role'];
	$posted_by_id=0;
	$company_id=0;
	$email=$_SESSION["email"];
	$pass=$_SESSION["password"];
	$sql1="select id from user_account where email='$email' AND password='$pass'";
	// Exception Handling //
	if($res=mysqli_query($con,$sql1)){
		while($row=mysqli_fetch_array($res))
			$posted_by_id=$row['id'];
	}
	$sql2="select id from company where hr_id='$posted_by_id'";
	// Exception handling // 
	if($res2=mysqli_query($con,$sql2)){
		while($row2=mysqli_fetch_array($res2))
			$company_id=$row2['id'];
	}
	$dat= date("d/m/y");
	$sql3="insert into jobpost(postedById, companyID, jobDescription, isActive, createdDate) values ('$posted_by_id', '$company_id', '$jobRole', 1, '$dat')";
	if(!mysqli_query($con,$sql3)) {
		echo 'Query Error: Record Not Inserted';
	}
	else {
		echo 'Record Inserted Successfully';
	}
	$jobpID=0;
	$sql4="select id from jobpost where postedByID='$posted_by_id'";
	if($res3=mysqli_query($con,$sql4)){
		while($row3=mysqli_fetch_array($res3))
			$jobpID=$row3['id'];
	}
	foreach($_POST['skillSetName'] as $checkBox) {
			$sql5="insert into jobpostskillset(jobPostID, skillSetID) values( '$jobpID', '$checkBox')";
			if(!mysqli_query($con, $sql5)){
				echo 'Query Error: Not Inserted';
			}
	}
	header("refresh:1;url=HRsignup.html");
?>
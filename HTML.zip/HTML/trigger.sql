CREATE TRIGGER count_users AFTER INSERT ON user_account	
FOR EACH ROW 
BEGIN
	IF NEW.id = 0 THEN  
		UPDATE user_count
		SET HR=HR+1;
	ELSE	
		UPDATE user_count
		SET jobseeker=jobseeker+1;
	END IF;
END;
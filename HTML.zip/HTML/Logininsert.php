<?php
	session_start();
	$con= mysqli_connect('localhost','root','');
	if(!$con)
	{
		echo 'Not Connected to server';
	}
	if(!mysqli_select_db($con,'job_portal'))
	{
		echo 'db not selected';
	}
	$email=$_POST['Email'];
	$pass=$_POST['Password'];
	$dob=$_POST['DateofBirth'];
	$gender=$_POST['Gender'];
	$type=$_POST['type'];
	if($type == 'HR'){
		$type=0;
		$_SESSION["startEmail"]=$email;
	}
	else{
		$type=1;
		$_SESSION["startEmail"]=$email;
	}
	$sql = "INSERT INTO user_account (gender,type_id,email,password,dob) VALUES ('$gender','$type','$email','$pass','$dob')";	
	$sql2= "UPDATE user_count SET HR=HR+1";
	
	
	$sql3= "UPDATE user_count SET jobseeker=jobseeker+1";
	if(!mysqli_query($con,$sql)) {
		echo 'Query Error:Record not inserted';
		die();
	}
	else {
		echo 'Inserted Record Successfully';	
	}
	if($type == 0){
		if(!mysqli_query($con, $sql2)){
			echo 'Failed';
		}
		else{
			echo 'Success';
		}
		header("refresh:2;url=HRprofile.html");
	}
	else{
		mysqli_query($con, $sql3);
		header("refresh:2;url=jscreateapplication.html");
	}
?>	
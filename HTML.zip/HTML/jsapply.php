
<?php
	session_start();
	$con= mysqli_connect('localhost','root','');
	if(!$con)
	{
		echo 'Not Connected to server';
	}
	if(!mysqli_select_db($con,'job_portal'))
	{
		echo 'db not selected';
	}
	$jsemail=$_SESSION["email"];
	$jspass=$_SESSION["password"];
	$jobPostCount=0;
	
	$sql1="select id from user_account where email='$jsemail' AND password='$jspass'";
	if($res1=mysqli_query($con,$sql1)){
		while($row1 = mysqli_fetch_array($res1))
			$js_id=$row1['id'];
	}

	$sql2="select distinct jobpostskillset.jobPostID from jobpostskillset, seekerskillset where jobpostskillset.skillSetID = seekerskillset.skillSetID and seekerskillset.user_account_id='$js_id'";
	if($res2=mysqli_query($con,$sql2)){
		while($row2= mysqli_fetch_array($res2)){
			$jobPost[$jobPostCount] = $row2['jobPostID'];
			$jobPostCount = $jobPostCount + 1;
		}
	}
	foreach ($jobPost as $value){
		$sql3="select company.Name, jobpost.jobDescription from company, jobpost where jobpost.id = '$value' and company.ID = jobpost.companyID";
		if($res3 = mysqli_query($con, $sql3)) {
			while($row3= mysqli_fetch_array($res3)) {
				echo "<table>";				
				echo "<tr>";
				echo "<td>".$row3['Name']."</td>";
				echo "<br>";
				echo "<button>APPLY</button>";
				echo "<br>";
				echo "<td>".$row3['jobDescription']."</td>";
				echo "<br>";
			}	
		}
	}  
?>
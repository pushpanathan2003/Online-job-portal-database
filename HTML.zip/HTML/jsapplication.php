<?php

	session_start();
	$con= mysqli_connect('localhost','root','');
	if(!$con)
	{
		echo 'Not Connected to server';
	}
	if(!mysqli_select_db($con,'job_portal'))
	{
		echo 'db not selected';
	}
	$semail=$_SESSION["startEmail"];
	$JSID=0;
	$fname=$_POST['firstName'];
	$sname=$_POST['lastName'];
	$uname=$_POST['universityName'];
	$dname=$_POST['degreeName'];
	$sDate=$_POST['startDate'];
	$eDate=$_POST['endDate'];
	$major=$_POST['Major'];
	$CGPA=$_POST['CGPA'];
	$comname=$_POST['companyName'];
	$jobRole=$_POST['jobRole'];
	$StartDate=$_POST['StartDate'];
	$EndDate=$_POST['EndDate'];
	$sql="select id from user_account where email='$semail'";
	if ($res = mysqli_query($con, $sql)) { 
		while ($row = mysqli_fetch_array($res)) {
			$JSID=$row['id'];
		}
	}
	$sql = "INSERT INTO jobseeker(user_account_id, First_Name, Last_Name) values('$JSID', '$fname', '$sname')";
	$sql2= "INSERT INTO education(user_account_id, degreeName, universityName, major, CGPA, start_date, end_date) values('$JSID', '$dname','$uname', '$major', '$CGPA', '$StartDate', '$EndDate')";
	$sql3= "INSERT INTO experience(user_account_id, companyName, jobRole, startDate, endDate) values ('$JSID', '$comname', '$jobRole', '$StartDate', '$EndDate')";
	foreach($_POST['skillSetName'] as $checkBox){
			$sql5="INSERT INTO seekerskillset(user_account_id, skillSetID) values('$JSID','$checkBox')";
			if(!mysqli_query($con, $sql5)){
				echo 'Query Failed: Record Not Inserted';
			}
		echo "<br>";
	}
	echo "<br>";	
	if(!mysqli_query($con, $sql) && !mysqli_query($con, $sql2) && !mysqli_query($con, $sql3)){
		echo 'Query Failed: Record Not Inserted';
	}	
	else{
		echo 'Inserted Recorded Successfully';
	}
	echo "<br>";
	echo "<br>";
	header("refresh:2;url=Login.html");
	
?>		
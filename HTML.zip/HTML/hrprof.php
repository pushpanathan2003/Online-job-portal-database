<?php
	session_start();
	$con= mysqli_connect('localhost','root','');
	if(!$con)
	{
		echo 'Not Connected to server';
	}
	if(!mysqli_select_db($con,'job_portal'))
	{
		echo 'db not selected';
	}
	$nameOfCompany=$_POST['nameOfCompany'];
	$desc=$_POST['Description'];
	$toc=$_POST['typeOfCompany'];
	$url=$_POST['URL'];
	$hrEmail=$_SESSION["startEmail"];
	$hrID=0;
	$sql="select id from user_account where email='$hrEmail'";
	if ($res = mysqli_query($con, $sql)) { 
		while ($row = mysqli_fetch_array($res)) {
			$hrID=$row['id'];
		}
	}
	$sql1 = "INSERT INTO company (Name,Description,type_id,URL,hr_id) VALUES('$nameOfCompany','$desc','$toc','$url','$hrID')";
	if(!mysqli_query($con,$sql1))
	{
		echo 'Query Error: Record Not inserted';
	}
	else
	{
		echo 'Inserted Record Successfully';
	}
	header("refresh:1;url=Login.html");

?>	